/**
 * Week 6 Assignment - Static JSX Output
 * Author: Nira Tamanna Yeasmin (M23W7585)
 */

function App() {
  return (
    <div className="p-6 font-sans">
      <h1 className="text-3xl text-blue-500 font-bold mb-4">Welcome to My React Page</h1>
      <p className="text-lg mb-4">Hi! I’m Nira. This is my Week 6 assignment using React, Vite, and Tailwind CSS.</p>

      <ul className="list-disc pl-6 mb-4">
        <li>Reading books 📚</li>
        <li>Designing websites 💻</li>
        <li>Exploring languages 🌍</li>
      </ul>

      <img
        src="https://via.placeholder.com/150"
        alt="Placeholder"
        className="w-40 border-4 border-pink-400 rounded-lg"
      />
    </div>
  )
}

export default App
