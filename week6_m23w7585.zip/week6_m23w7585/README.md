# Week 6 React application

Instructions:

- Run `npm install` for installing the dependencies
- Run `npm run dev` to run the app
